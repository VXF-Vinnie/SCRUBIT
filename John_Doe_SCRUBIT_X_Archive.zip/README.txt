SCRUBIT Synthetic X/Twitter-Style Test Archive
User: John Doe (@JohnDoeCollege)
Posts: 60

Entirely fictional synthetic data for hackathon testing.
This resembles the useful structure of an X archive but is not an official X export.

data/tweets.js contains the posts for parser/AI testing.
The archive deliberately mixes ordinary positive posts with potential professional-reputation risk signals.
