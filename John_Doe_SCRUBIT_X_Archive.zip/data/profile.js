window.YTD.profile.part0 = [
  {
    "profile": {
      "description": {
        "bio": "College student | learning as I go | fictional SCRUBIT demo account"
      }
    }
  }
];