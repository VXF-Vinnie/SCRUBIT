window.YTD.tweets.part0 = [
  {
    "tweet": {
      "id_str": "1845000000000000000",
      "created_at": "Sat Aug 20 18:00:00 +0000 2022",
      "full_text": "moving into the dorm today. somehow fit my entire life into one car lol",
      "lang": "en",
      "favorite_count": "0",
      "retweet_count": "0",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000001",
      "created_at": "Sat Aug 27 18:07:00 +0000 2022",
      "full_text": "first week of college survived. met some genuinely great people already",
      "lang": "en",
      "favorite_count": "13",
      "retweet_count": "3",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000002",
      "created_at": "Sat Sep 03 18:14:00 +0000 2022",
      "full_text": "tailgate -> party -> no memory of getting home. apparently college is going well 💀",
      "lang": "en",
      "favorite_count": "26",
      "retweet_count": "6",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000003",
      "created_at": "Sat Sep 10 18:21:00 +0000 2022",
      "full_text": "why did I post 14 videos last night 😭 I was absolutely gone",
      "lang": "en",
      "favorite_count": "39",
      "retweet_count": "9",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000004",
      "created_at": "Sun Sep 18 18:28:00 +0000 2022",
      "full_text": "Sunday recovery mode. water, breakfast burrito, and pretending last night never happened",
      "lang": "en",
      "favorite_count": "52",
      "retweet_count": "12",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000005",
      "created_at": "Sun Sep 25 18:35:00 +0000 2022",
      "full_text": "Professor Thompson really assigned a project Friday night due Monday. does this man have hobbies",
      "lang": "en",
      "favorite_count": "65",
      "retweet_count": "15",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000006",
      "created_at": "Sun Oct 02 18:42:00 +0000 2022",
      "full_text": "library until midnight. who am I becoming",
      "lang": "en",
      "favorite_count": "78",
      "retweet_count": "18",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000007",
      "created_at": "Sat Oct 15 18:49:00 +0000 2022",
      "full_text": "got pulled over doing 82 in a 65. officer asked why I was speeding and I genuinely had no answer",
      "lang": "en",
      "favorite_count": "91",
      "retweet_count": "2",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000008",
      "created_at": "Sun Oct 16 18:56:00 +0000 2022",
      "full_text": "speeding ticket secured 🫡 there goes my food budget",
      "lang": "en",
      "favorite_count": "104",
      "retweet_count": "5",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000009",
      "created_at": "Sat Oct 29 18:03:00 +0000 2022",
      "full_text": "Halloween party was insane. woke up on my friend's couch still wearing half my costume",
      "lang": "en",
      "favorite_count": "117",
      "retweet_count": "8",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000010",
      "created_at": "Sat Nov 05 18:10:00 +0000 2022",
      "full_text": "my cousin got married today!! beautiful ceremony and somehow I didn't cry until the speeches",
      "lang": "en",
      "favorite_count": "130",
      "retweet_count": "11",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000011",
      "created_at": "Mon Nov 14 18:17:00 +0000 2022",
      "full_text": "Professor Miller: maybe actually teach the material instead of reading 70 slides at us",
      "lang": "en",
      "favorite_count": "6",
      "retweet_count": "14",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000012",
      "created_at": "Sun Nov 20 18:24:00 +0000 2022",
      "full_text": "made pasta from scratch tonight. 7/10 appearance, 10/10 taste",
      "lang": "en",
      "favorite_count": "19",
      "retweet_count": "17",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000013",
      "created_at": "Fri Dec 02 18:31:00 +0000 2022",
      "full_text": "finals week has me questioning every decision that led me here",
      "lang": "en",
      "favorite_count": "32",
      "retweet_count": "1",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000014",
      "created_at": "Sun Dec 18 18:38:00 +0000 2022",
      "full_text": "home for winter break. mom already asked why I sleep until noon",
      "lang": "en",
      "favorite_count": "45",
      "retweet_count": "4",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000015",
      "created_at": "Thu Jan 12 18:45:00 +0000 2023",
      "full_text": "new semester new me (this statement expires in approximately 4 days)",
      "lang": "en",
      "favorite_count": "58",
      "retweet_count": "7",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000016",
      "created_at": "Sat Jan 28 18:52:00 +0000 2023",
      "full_text": "party was ridiculous. apparently I tried to order an uber while already sitting in an uber",
      "lang": "en",
      "favorite_count": "71",
      "retweet_count": "10",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000017",
      "created_at": "Fri Feb 03 18:59:00 +0000 2023",
      "full_text": "found videos from last weekend and I am NEVER drinking that much again",
      "lang": "en",
      "favorite_count": "84",
      "retweet_count": "13",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000018",
      "created_at": "Tue Feb 14 18:06:00 +0000 2023",
      "full_text": "happy valentine's day to my true love: discounted takeout",
      "lang": "en",
      "favorite_count": "97",
      "retweet_count": "16",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000019",
      "created_at": "Mon Feb 27 18:13:00 +0000 2023",
      "full_text": "parking services gave me ANOTHER ticket. adding it to the collection because I am absolutely not paying these yet",
      "lang": "en",
      "favorite_count": "110",
      "retweet_count": "0",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000020",
      "created_at": "Wed Mar 01 18:20:00 +0000 2023",
      "full_text": "current unpaid parking ticket total is embarrassing. campus parking enforcement is my biggest enemy",
      "lang": "en",
      "favorite_count": "123",
      "retweet_count": "3",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000021",
      "created_at": "Sat Mar 11 18:27:00 +0000 2023",
      "full_text": "spring break starts NOW 🌴",
      "lang": "en",
      "favorite_count": "136",
      "retweet_count": "6",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000022",
      "created_at": "Mon Mar 13 18:34:00 +0000 2023",
      "full_text": "day 2 of spring break and we've already lost a shoe, a phone charger, and most of our dignity",
      "lang": "en",
      "favorite_count": "12",
      "retweet_count": "9",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000023",
      "created_at": "Wed Mar 22 18:41:00 +0000 2023",
      "full_text": "back to class and Professor Thompson is already acting like spring break personally offended him",
      "lang": "en",
      "favorite_count": "25",
      "retweet_count": "12",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000024",
      "created_at": "Sat Apr 08 18:48:00 +0000 2023",
      "full_text": "smoked way too much weed last night and spent 20 minutes looking for my phone while using its flashlight",
      "lang": "en",
      "favorite_count": "38",
      "retweet_count": "15",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000025",
      "created_at": "Sun Apr 09 18:55:00 +0000 2023",
      "full_text": "note to self: maybe don't tweet while high",
      "lang": "en",
      "favorite_count": "51",
      "retweet_count": "18",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000026",
      "created_at": "Fri Apr 21 18:02:00 +0000 2023",
      "full_text": "volunteered at the food bank this morning. really good crew and a surprisingly fun day",
      "lang": "en",
      "favorite_count": "64",
      "retweet_count": "2",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000027",
      "created_at": "Fri May 05 18:09:00 +0000 2023",
      "full_text": "passed every class somehow. summer officially unlocked",
      "lang": "en",
      "favorite_count": "77",
      "retweet_count": "5",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000028",
      "created_at": "Thu May 18 18:16:00 +0000 2023",
      "full_text": "got a summer job!! finally making money instead of exclusively spending it",
      "lang": "en",
      "favorite_count": "90",
      "retweet_count": "8",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000029",
      "created_at": "Fri Jun 02 18:23:00 +0000 2023",
      "full_text": "first paycheck hit and for approximately six minutes I felt financially responsible",
      "lang": "en",
      "favorite_count": "103",
      "retweet_count": "11",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000030",
      "created_at": "Thu Jun 15 18:30:00 +0000 2023",
      "full_text": "checked my credit score today. we will not be discussing the number",
      "lang": "en",
      "favorite_count": "116",
      "retweet_count": "14",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000031",
      "created_at": "Fri Jun 16 18:37:00 +0000 2023",
      "full_text": "apparently ignoring a credit card balance does NOT make it disappear. huge if true",
      "lang": "en",
      "favorite_count": "129",
      "retweet_count": "17",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000032",
      "created_at": "Tue Jul 04 18:44:00 +0000 2023",
      "full_text": "happy 4th 🇺🇸 burgers with the family and fireworks later",
      "lang": "en",
      "favorite_count": "5",
      "retweet_count": "1",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000033",
      "created_at": "Sat Jul 22 18:51:00 +0000 2023",
      "full_text": "road trip playlist might be the greatest contribution I've made to society",
      "lang": "en",
      "favorite_count": "18",
      "retweet_count": "4",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000034",
      "created_at": "Sat Aug 19 18:58:00 +0000 2023",
      "full_text": "junior year. apartment > dorm by approximately one million percent",
      "lang": "en",
      "favorite_count": "31",
      "retweet_count": "7",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000035",
      "created_at": "Sat Sep 02 18:05:00 +0000 2023",
      "full_text": "went out for 'one drink' and woke up at 11 wearing jeans and one sock. incredible",
      "lang": "en",
      "favorite_count": "44",
      "retweet_count": "10",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000036",
      "created_at": "Sun Sep 17 18:12:00 +0000 2023",
      "full_text": "Professor Harris took points off because my solution wasn't 'the intended method.' if it works it WORKS",
      "lang": "en",
      "favorite_count": "57",
      "retweet_count": "13",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000037",
      "created_at": "Fri Oct 06 18:19:00 +0000 2023",
      "full_text": "interviewed for an internship today. actually think it went pretty well",
      "lang": "en",
      "favorite_count": "70",
      "retweet_count": "16",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000038",
      "created_at": "Mon Oct 09 18:26:00 +0000 2023",
      "full_text": "GOT THE INTERNSHIP!!! genuinely cannot believe it",
      "lang": "en",
      "favorite_count": "83",
      "retweet_count": "0",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000039",
      "created_at": "Sat Oct 28 18:33:00 +0000 2023",
      "full_text": "made the questionable decision to smoke before the Halloween party. snacks have never tasted this good",
      "lang": "en",
      "favorite_count": "96",
      "retweet_count": "3",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000040",
      "created_at": "Sun Nov 12 18:40:00 +0000 2023",
      "full_text": "group project where one person disappears for three weeks and returns asking 'what can I do?' classic",
      "lang": "en",
      "favorite_count": "109",
      "retweet_count": "6",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000041",
      "created_at": "Thu Nov 23 18:47:00 +0000 2023",
      "full_text": "thanksgiving with the family ❤️ grateful for these people",
      "lang": "en",
      "favorite_count": "122",
      "retweet_count": "9",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000042",
      "created_at": "Sat Dec 09 18:54:00 +0000 2023",
      "full_text": "final project submitted with 11 minutes remaining. plenty of time",
      "lang": "en",
      "favorite_count": "135",
      "retweet_count": "12",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000043",
      "created_at": "Sat Jan 20 18:01:00 +0000 2024",
      "full_text": "just got pulled over again. apparently 'I was matching traffic' is not the legal defense I thought it was",
      "lang": "en",
      "favorite_count": "11",
      "retweet_count": "15",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000044",
      "created_at": "Sun Jan 21 18:08:00 +0000 2024",
      "full_text": "second speeding ticket. I may need to develop a personality that enjoys driving the speed limit",
      "lang": "en",
      "favorite_count": "24",
      "retweet_count": "18",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000045",
      "created_at": "Thu Feb 08 18:15:00 +0000 2024",
      "full_text": "Professor Miller might be the least organized human alive. three different due dates for the same assignment",
      "lang": "en",
      "favorite_count": "37",
      "retweet_count": "2",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000046",
      "created_at": "Sat Feb 24 18:22:00 +0000 2024",
      "full_text": "paid off one credit card today. small win but I'll take it",
      "lang": "en",
      "favorite_count": "50",
      "retweet_count": "5",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000047",
      "created_at": "Sat Mar 09 18:29:00 +0000 2024",
      "full_text": "birthday dinner for my little sister tonight. somehow she's cooler than me now",
      "lang": "en",
      "favorite_count": "63",
      "retweet_count": "8",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000048",
      "created_at": "Sat Mar 30 18:36:00 +0000 2024",
      "full_text": "okay story time: clipped a parked car pulling out last night, panicked, and drove away. woke up realizing that was an incredibly stupid thing to do",
      "lang": "en",
      "favorite_count": "76",
      "retweet_count": "11",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000049",
      "created_at": "Sun Mar 31 18:43:00 +0000 2024",
      "full_text": "went back to the parking lot and left my contact info for the owner. should've done that immediately.",
      "lang": "en",
      "favorite_count": "89",
      "retweet_count": "14",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000050",
      "created_at": "Fri Apr 12 18:50:00 +0000 2024",
      "full_text": "presentation went way better than expected. public speaking is slowly becoming less terrifying",
      "lang": "en",
      "favorite_count": "102",
      "retweet_count": "17",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000051",
      "created_at": "Sat May 04 18:57:00 +0000 2024",
      "full_text": "another semester DONE",
      "lang": "en",
      "favorite_count": "115",
      "retweet_count": "1",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000052",
      "created_at": "Mon Jun 10 18:04:00 +0000 2024",
      "full_text": "internship week 2. learning more here in a day than I expected",
      "lang": "en",
      "favorite_count": "128",
      "retweet_count": "4",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000053",
      "created_at": "Mon Jul 01 18:11:00 +0000 2024",
      "full_text": "manager let me demo the feature I worked on today. terrifying but it actually worked",
      "lang": "en",
      "favorite_count": "4",
      "retweet_count": "7",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000054",
      "created_at": "Sat Aug 17 18:18:00 +0000 2024",
      "full_text": "senior year loading...",
      "lang": "en",
      "favorite_count": "17",
      "retweet_count": "10",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000055",
      "created_at": "Thu Sep 05 18:25:00 +0000 2024",
      "full_text": "coffee before 8am classes should qualify as medical equipment",
      "lang": "en",
      "favorite_count": "30",
      "retweet_count": "13",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000056",
      "created_at": "Sat Sep 21 18:32:00 +0000 2024",
      "full_text": "finally paid the last of those ancient campus parking tickets. character development",
      "lang": "en",
      "favorite_count": "43",
      "retweet_count": "16",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000057",
      "created_at": "Fri Oct 11 18:39:00 +0000 2024",
      "full_text": "career fair went surprisingly well. talked to three companies I actually care about",
      "lang": "en",
      "favorite_count": "56",
      "retweet_count": "0",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000058",
      "created_at": "Sun Nov 03 18:46:00 +0000 2024",
      "full_text": "one year ago me would not believe I'm budgeting and checking my credit every month now",
      "lang": "en",
      "favorite_count": "69",
      "retweet_count": "3",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1845000000000000059",
      "created_at": "Sun Dec 15 18:53:00 +0000 2024",
      "full_text": "graduation getting close. weird feeling seeing four years of chaos turn into something I'm proud of",
      "lang": "en",
      "favorite_count": "82",
      "retweet_count": "6",
      "entities": {
        "hashtags": [],
        "urls": [],
        "user_mentions": []
      }
    }
  }
];