window.YTD.account.part0 = [
  {
    "account": {
      "username": "JohnDoeCollege",
      "accountDisplayName": "John Doe",
      "accountId": "999999999999999999"
    }
  }
];