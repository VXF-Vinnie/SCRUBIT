SCRUBIT fictional 10-post test archive.
3 severe examples, 2 elevated-risk examples, 5 benign examples.
